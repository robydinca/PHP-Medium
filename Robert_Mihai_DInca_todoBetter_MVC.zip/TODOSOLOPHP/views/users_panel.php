<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Lista de Usuarios</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
    <!-- Aquí podrías agregar enlaces a tus hojas de estilo o cualquier otro recurso necesario -->
</head>

<body>
    <?php
    // Incluir el archivo 'header.php' que contiene el encabezado de la página
    require_once "header.php";
    ?>

    <main>
        <?php
        // Incluir archivos y clases necesarias
        require_once "../config/config.php"; // Archivo de configuración de la base de datos
        require_once "../model/edit_user.php"; // Archivo de modelo para editar usuarios
        require_once "../controllers/Security.php"; // Clase Security para gestionar la seguridad

        // Crear una instancia de la clase Security
        $security = new Security();

        // Verificar si el usuario está autenticado y tiene el rol de administrador ('admin')
        if ($security->isAuth() && $security->getRole() === 'admin') {
            // Establecer conexión a la base de datos
            $conexion = new mysqli(HOST, USER, PASSWORD, DB, PORT);

            // Verificar si hubo un error en la conexión
            if ($conexion->connect_errno) {
                die("Error de conexión: " . $conexion->connect_error);
            }

            // Consultar todos los usuarios de la base de datos
            $consulta = "SELECT * FROM users";
            $resultado = $conexion->query($consulta);

            // Mostrar la tabla con los datos de los usuarios
            echo "<h2>Lista de Usuarios</h2>";
            echo "<table border='1'>";
            echo "<tr><th>Nombre</th><th>Apellido</th><th>Login</th><th>Email</th><th>Rol</th><th>Acciones</th></tr>";

            // Iterar sobre cada usuario y mostrar sus datos en la tabla
            while ($fila = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$fila['name']}</td>";
                echo "<td>{$fila['last_name']}</td>";
                echo "<td>{$fila['login']}</td>";
                echo "<td>{$fila['email']}</td>";
                echo "<td>{$fila['role']}</td>";
                echo "<td>
                          <a href='../model/edit_user.php?id={$fila['login']}'>Editar</a> | 
                          <a href='../model/delete_user.php?id={$fila['login']}'>Borrar</a>
                      </td>";
                echo "</tr>";
            }

            // Cerrar la tabla y agregar un enlace para agregar un nuevo usuario
            echo "</table>";
            echo "<a href='../model/add_user.php'>Agregar Nuevo Usuario</a>";
        } else {
            // Mensaje de acceso denegado si el usuario no es un administrador autenticado
            echo "Acceso denegado. Debes tener permisos de administrador para ver esta página.";
        }
        ?>
    </main>
</body>

</html>
