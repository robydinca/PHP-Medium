<?php
session_start();
?>
<header class="header">
    <h1>todo.Ai</h1>
    <nav class="header__nav">
        <?php
        // Verifica si la URL actual contiene "index.php"
$isIndexPage = strpos($_SERVER['REQUEST_URI'], 'index.php') !== false;

if ($isIndexPage) {
    echo "<ul>";
    echo "<li><a href='./index.php'>Home</a></li>";
    echo "<li><a href='./views/dashboard.php'>Dashboard</a></li>";
    echo "</ul>";
}
?>
    </nav>
    <div class="header__auth">
    <?php
    // Verifica si el usuario está autenticado
    $isLoggedIn = isset($_SESSION['login']);

    if ($isLoggedIn) {
        // Si el usuario está autenticado, muestra el enlace a profile.php con el parámetro 'id'
        echo '<a href="./logout.php" class="btn btn--login">Logout</a>';
        echo '<a href="./profile.php?id=' . $_SESSION['login'] . '" class="btn btn--sig nup">Profile Info</a>';
    } else {
        // Si el usuario no está autenticado, muestra los botones de inicio de sesión y registro
        echo '<a href="./views/login.php" class="btn btn--login">Login</a>';
        echo '<a href="./views/register.php" class="btn btn--sig nup">Sign Up</a>';
    }
    ?>
    </div>
</header>
<?php

?>
