<?php
// Incluir el archivo de configuración que contiene los datos de conexión a la base de datos
require_once "./config/config.php";

// Crear una conexión a la base de datos usando los datos del archivo de configuración
$conexion = new mysqli(HOST, USER, PASSWORD, DB, PORT);

// Verificar si hubo un error en la conexión
if ($conexion->connect_errno) {
    // En caso de error, muestra un mensaje y finaliza la ejecución del script
    die("Error de conexión: " . $conexion->connect_error);
}

// Verificar si la solicitud al script es de tipo POST (cuando se envía el formulario)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario enviado por el método POST
    $login = $_POST["login"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Definir un rol por defecto para el usuario (en este caso, 'user')
    $rol = 'user';

    // Generar un hash de la contraseña usando password_hash() para almacenarla de forma segura
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Generar un valor aleatorio (salt) para mejorar la seguridad de la contraseña
    $salt = bin2hex(random_bytes(10));

    // Obtener los valores opcionales del formulario (nombre y apellidos) o establecerlos como NULL si están vacíos
    $nombre = !empty($_POST["nombre"]) ? $_POST["nombre"] : NULL;
    $apellidos = !empty($_POST["apellidos"]) ? $_POST["apellidos"] : NULL;

    // Consulta preparada para insertar un nuevo usuario en la base de datos
    $consulta = "INSERT INTO users (name, last_name, salt, login, email, password, role) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($consulta);

    // Vincular los parámetros a la consulta preparada
    $stmt->bind_param("sssssss", $nombre, $apellidos, $salt, $login, $email, $passwordHash, $rol);

    // Ejecutar la consulta preparada para insertar el nuevo usuario en la base de datos
    if ($stmt->execute()) {
        // Si la ejecución es exitosa, mostrar un mensaje de éxito
        echo "Usuario creado correctamente<br>";
    } else {
        // Si hay un error durante la ejecución, mostrar el mensaje de error correspondiente
        echo "Error al crear el usuario: " . $conexion->error . "<br>";
    }

    // Cerrar la consulta preparada y la conexión a la base de datos
    $stmt->close();
    $conexion->close();

    // Redirigir al usuario a la página de dashboard después de crear el usuario
    header("Location: ./dashboard.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuarios</title>
    <link type="text/css" rel="stylesheet" href="../assets/login.css">
</head>

<body>
    <!-- Formulario de registro de usuarios -->
    <form action="" method="post">
        <h1>Registro de Usuarios</h1>
        <!-- Campos del formulario para ingresar información del usuario -->
        <input type="text" name="nombre" id="nombre" placeholder="Nombre">
        <input type="text" name="apellidos" id="apellidos" placeholder="Apellidos">
        <input type="text" name="login" id="login" placeholder="Usuario" required>
        <input type="email" name="email" id="email" placeholder="Correo electrónico" required>
        <input type="password" name="password" id="password" placeholder="Contraseña" required>
        <!-- Botón de envío del formulario -->
        <input type="submit" value="Enviar" class="boton">
    </form>
</body>

</html>
