<?php
require_once "../config/config.php";
require_once "../controllers/Security.php"; 
require_once "../controllers/Users.php"; // Asegúrate de incluir el archivo donde se encuentra la clase Users

$security = new Security(); 

$conexion = new mysqli(HOST, USER, PASSWORD, DB, PORT);

if ($conexion->connect_errno) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Iniciar la sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $login = $_POST['login'];

    $users = new Users($conexion); // Crear una instancia de la clase Users

    // Obtener la información del usuario por su login
    $usuario = $users->fetchUser($login);
    
    if ($usuario) {
        // Actualizar los datos del usuario
        $updatedUserData = array(
            'login' => $login,
            'name' => $_POST['name'],
            'last_name' => $_POST['last_name'],
            'email' => $_POST['email']
            // Puedes incluir más campos para actualizar si es necesario
        );

        // Realizar la actualización de datos
        $result = $users->updateUserData($updatedUserData);

        if ($result) {
            echo "Los datos del usuario se han actualizado correctamente.";
            // Puedes redirigir a alguna página después de la actualización si es necesario
        } else {
            echo "Error al actualizar los datos del usuario.";
        }
    } else {
        echo "No se encontró ningún usuario con el ID proporcionado.";
    }
} else {
    echo "No se recibieron datos para actualizar.";
}
?>
