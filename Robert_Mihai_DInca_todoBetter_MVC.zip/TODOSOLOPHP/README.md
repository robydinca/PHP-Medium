# todoBetter - Plataforma Multifuncional de Organización Personal con Asistente IA

todoBetter es una plataforma web multifuncional diseñada para ayudar a los usuarios a organizar sus tareas diarias, llevar un seguimiento de su progreso físico y nutricional, y gestionar sus estudios y apuntes de cursos. La aplicación cuenta con una interfaz intuitiva y amigable que centraliza diversas funcionalidades y ofrece asesoramiento personalizado a través de un asistente de inteligencia artificial.

## Funcionalidades Principales

### Lista de Tareas
Los usuarios pueden crear, editar y eliminar tareas pendientes, establecer fechas límite y prioridades, y marcar las tareas completadas.

### Apuntes y Notas sobre Cursos
Espacio dedicado para tomar notas, registrar ideas clave o guardar recursos importantes relacionados con los cursos que están siguiendo los usuarios.

### Recetas con Contador de Calorías
Ofrece una amplia variedad de recetas y menús personalizables a las preferencias del usuario, con ayuda de la IA. Muestra el recuento de calorías de cada receta para una nutrición más informada. También permite crear listas de la compra basadas en estas recetas.

### Rutinas de Entrenamiento Personalizadas
Los usuarios pueden diseñar rutinas de ejercicios personalizadas, seleccionar ejercicios específicos, establecer repeticiones, series y tiempos de descanso, y hacer un seguimiento de su progreso en el entrenamiento con la ayuda del asistente virtual.

## Uso de la Aplicación

Los usuarios pueden acceder a la aplicación web a través de una interfaz de usuario amigable que les permite navegar sin problemas por las diferentes funcionalidades. Pueden iniciar sesión para acceder a todas las características o explorar algunas áreas específicas sin autenticarse.

## Roles de Usuarios

- **Usuario No Identificado:** Visitante anónimo que accede al sitio sin autenticarse.
- **Usuario Registrado:** Crea una cuenta y accede a las funcionalidades de la aplicación.
- **Administrador:** Gestiona y supervisa la aplicación, con permisos administrativos para gestionar cuentas de usuarios.

## Instalación

1. Clona el repositorio de la aplicación.
2. Configura la base de datos ejecutando los scripts proporcionados en `config/install.sql`.
3. Configura las credenciales de la base de datos en `config/install.php`.
3.5 Configura las credenciales del primer usuario administrador `config/register.php`.
4. Abre la terminal y navega al directorio raíz de la aplicación.
5. Ejecuta `composer install` para instalar las dependencias.
6. Accede a la aplicación a través de un servidor local.

## Estructura del Proyecto

El proyecto sigue una estructura MVC (Modelo-Vista-Controlador), dividido en carpetas para los controladores, modelos, vistas, configuración, activos y otros directorios relacionados.

Para más detalles sobre las vistas, modelos, controladores y la configuración de la aplicación, consulta la estructura de carpetas en el repositorio.

## Contribuciones

¡Las contribuciones son bienvenidas! Si encuentras errores, problemas o mejoras posibles, no dudes en abrir un problema o enviar una solicitud de extracción.

## Autores

- Robert Mihai Dinca https://github.com/robydinca

## Licencia

Este proyecto está bajo la [Licencia XYZ] https://www.fsf.org/

