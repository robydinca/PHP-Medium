<?php
define("HOST", "172.21.0.2");
define("USER", "root");
define("PASSWORD", "7227");
define("DB", "exam_u2");
define("PORT", "3306");
?>
