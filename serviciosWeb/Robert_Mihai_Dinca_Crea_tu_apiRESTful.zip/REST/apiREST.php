<?php

class apiREST
{
    private $controller;
    private $resource;

    public function __construct($controller, $resource)
    {
        $this->controller = $controller;
        $this->resource = $resource;
    }

    public function action($endpoint)
    {
        $method = $_SERVER['REQUEST_METHOD'];
    
        switch ($method) {
            case 'GET':
                if ($endpoint === 'api/modelo/') {
                    $this->index();
                } elseif (preg_match('/modelo\/(\d+)/', $endpoint, $matches)) {
                    $numero = $matches[1];
                    $this->show($numero);
                } else {
                    var_dump($method);
                    $this->errorResponse('Invalid endpoint for GET request');
                }
                break;
    
            case 'POST':
                if ($endpoint === 'api/modelo/store') {
                    $this->store();
                } else {
                    $this->errorResponse('Invalid endpoint for POST request');
                }
                break;
    
            case 'DELETE':
                // Utilizar expresión regular para extraer el número después de "/destroy/"
                if (preg_match('/\/destroy\/(\d+)/', $endpoint, $matches)) {
                    $this->destroy($matches[1]);
                } elseif ($endpoint === 'api/modelo/') {
                    $this->errorResponse('Invalid endpoint for DELETE request');
                } else {
                    $this->errorResponse('Invalid endpoint for DELETE request');
                }
                break;
    
            default:
                $this->errorResponse('Invalid request method');
                break;
        }
    }
    
    

    private function index()
    {
        $data = $this->controller->getAll();
        $this->jsonResponse($data);
    }

    private function show($id)
    {
        $data = $this->controller->getById($id);
        $this->jsonResponse($data);
    }
    private function store() {
        // Obtener datos del formulario POST
        $name = $_POST['name'];
        $brand = $_POST['brand'];
        $year = $_POST['year'];
    
        // Crear un array asociativo con los datos
        $postData = array(
            "name" => $name,
            "brand" => $brand,
            "year" => $year
        );
    
        // Llamar al controlador para crear el modelo
        $data = $this->controller->create($postData);
    
        // Responder con un JSON válido
        header('Content-Type: application/json');
        echo json_encode($data);
    }
    
    
    private function destroy($id)
    {
        $success = $this->controller->delete($id);

        if ($success) {
            $this->jsonResponse(['success' => true]);
        } else {
            $this->errorResponse('Failed to delete resource');
        }
    }

    private function jsonResponse($data)
    {
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function errorResponse($message)
    {
        $this->jsonResponse(['error' => $message]);
        exit;
    }
}
